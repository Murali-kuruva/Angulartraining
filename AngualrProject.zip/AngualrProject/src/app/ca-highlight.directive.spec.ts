import { CaHighlightDirective } from './ca-highlight.directive';

xdescribe('CaHighlightDirective', () => {
  it('should create an instance', () => {
    const directive = new CaHighlightDirective(null,null);
    expect(directive).toBeTruthy();
  });
});
