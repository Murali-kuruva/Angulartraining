import {CaRainbowColorDirective} from './ca-rainbow-color.directive'; 


xdescribe('CaRainbowColorDirective', () => {
  it('should create an instance', () => {
    const directive = new CaRainbowColorDirective(null,null);
    expect(directive).toBeTruthy();
  });
});
