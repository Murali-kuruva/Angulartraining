import { RatingadvisePipe } from './ratingadvise.pipe';

xdescribe('RatingavisePipe', () => {
  it('create an instance', () => {
    const pipe = new RatingadvisePipe();
    expect(pipe).toBeTruthy();
  });
});
