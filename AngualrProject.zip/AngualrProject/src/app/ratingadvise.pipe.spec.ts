import { RatingadvisePipe } from './ratingadvise.pipe';

describe('RatingadvisePipe', () => {
  it('create an instance', () => {
    const pipe = new RatingadvisePipe();
    expect(pipe).toBeTruthy();
  });
});
