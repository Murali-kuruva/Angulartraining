import { AltvaluePipe } from './altvalue.pipe';

xdescribe('AltvaluePipe', () => {
  it('create an instance', () => {
    const pipe = new AltvaluePipe();
    expect(pipe).toBeTruthy();
  });
});
