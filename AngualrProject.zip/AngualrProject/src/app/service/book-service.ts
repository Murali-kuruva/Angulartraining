import {Book} from './book'; 

export interface BookService{  
    getBooks();    
    
}

