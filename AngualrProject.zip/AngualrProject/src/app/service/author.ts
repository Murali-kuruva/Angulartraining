


export interface Author{
Id?:string;
aid:string;
name:string;
biography?:string;
photograph?:string;
email?:string;
books?:string[];
}